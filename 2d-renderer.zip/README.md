# Glad + GLFW + Cmake FetchContent

This is a basic setup for CMake w/ FetchContent + glad + GLFW.

### Requirements

1. python3 + `pip install glad` or `sudo apt install python3-glad`
2. CMake `3.16` or higher
3. opengl `sudo apt install freeglut3-dev mesa-utils libglu1-mesa-dev mesa-common-dev`